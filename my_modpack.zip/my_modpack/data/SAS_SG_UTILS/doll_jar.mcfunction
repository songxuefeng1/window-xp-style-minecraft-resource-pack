title "DOLL.JAR ACTIVATE VOTING...(YES/NO)" title "SETUPING DOLL.JAR..."
execute at @r run summon mannequin ~ ~ ~ {pose:"sleeping",profile:SAS_SG_2}
execute at @r run summon mannequin ~ ~ ~ {pose:"standing",profile:SAS_SG_2}
execute at @r run summon mannequin ~ ~ ~ {pose:"crouching",profile:SAS_SG_2}
execute at @r run spreadplayers ~ ~ 10 10 false @e[type=mannequin,distance=..11]