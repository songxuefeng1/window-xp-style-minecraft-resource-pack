summon creeper ~ ~ ~ {CustomName:"\"泰坦苦力怕\"",Health:10005.0f,Tags:[huge_creeper_tag],attributes:[{base:100.0f,id:"minecraft:scale"}]}
effect give @e[tag=huge_creeper_tag] speed infinite 12
effect give @e[tag=huge_creeper_tag] jump_boost infinite 5